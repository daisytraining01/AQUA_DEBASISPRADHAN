package corejava;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class File {



	public static void main(String[] args) {
		try {
			List<String> allLines = Files.readAllLines(Paths.get("C:\\Users\\User\\Downloads"));
			for (String line : allLines) {
				System.out.println(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
