package corejava;

public class Compare {
	
	public static String charRemoveAt(String str, int p) {  
        return str.substring(0, p) + str.substring(p + 1);  
     }  
	public static void main(String[] args) {
		
        
		String s1 = "Rest Assured";
	    String s2 = " ";
	    
	    System.out.println(charRemoveAt(s1, 4));  
    
        if(s1.equals(s2)){
            System.out.println("Both strings are equal.");
        } else {
            System.out.println("Both strings are not equal.");
        }

        

	}

}
