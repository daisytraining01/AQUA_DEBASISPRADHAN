package corejava;

public class Overloading {
	
		   
		   Overloading(){
			System.out.println("Constructor of Parent");
		   }
		  public void getDisplay(){
			System.out.println("Parent Method");
		   }
		}
		class JavaExample extends Overloading{
		   JavaExample(){
			System.out.println("Constructor of Child");
		   }
		   private void setDisplay(){
			System.out.println("Child Method");
		        
			
		   }
		   public static void main(String args[]){
			//Creating the object of child class
			JavaExample obj = new JavaExample();
			obj.disp();
		   }
		private void disp() {
			
			
		}
		}
