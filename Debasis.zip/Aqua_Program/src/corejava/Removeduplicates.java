package corejava;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Removeduplicates {
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  HashMap<String, String> map = new HashMap<String, String>();
		    map.put("1", "Testvalue1");
		    map.put("2", "Testvalue2");
		    map.put("3", "Testvalue3");
		    map.put("4", "Testvalue4");
		    map.put("5", "Testvalue5");

		    Set<String> keys = map.keySet(); // The set of keys in the map.

		    Iterator<String> keyIter = keys.iterator();

		    while (keyIter.hasNext()) {
		        String key = keyIter.next();
		        String value = map.get(key);

		        System.out.println(key + "\t" + value);

		        String nextValue = map.get(key);

		        if (value.equals(nextValue)) {
		            map.remove(key);
		        }
		    }
		    System.out.println(map);
		}
	


}
